package be.dauntless.twofa;

import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;

import java.util.Arrays;
import java.util.Base64;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.*;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONException;
import org.json.JSONObject;

import co.paystack.android.design.widget.PinPadView;

public class MainActivity extends AppCompatActivity {


    ProgressBar p;
    private int c;
    private int d = 30;

    private String getVaultURL = "http://99.81.5.42:9009/getvault";
    private String submitKeyURL = "http://99.81.5.42:9009/submitkey";
    private Handler mHandler;
    private RequestQueue queue;

    private ClassLoader cl;
    private Object vault;

    private void updateProgress()
    {
        c ++;
        c %= d;
        p.setProgress((int)(((double)c/(double)d)*100));

        if(c == 0){
            getNewVault();
        }

    }

    // Base64-encoded String ciphertext -> String plaintext
    public static String decrypt(String ciphertext) {
        String key = "ca1111c9f4a927971077eb12cf0a4fcb".substring(0, 16);
        try {
            byte[] cipherbytes = Base64.getDecoder().decode(ciphertext);

            byte[] initVector = Arrays.copyOfRange(cipherbytes,0,16);

            byte[] messagebytes = Arrays.copyOfRange(cipherbytes,16,cipherbytes.length);

            IvParameterSpec iv = new IvParameterSpec(initVector);
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);

            // Convert the ciphertext Base64-encoded String back to bytes, and
            // then decrypt
            byte[] byte_array = cipher.doFinal(messagebytes);

            // Return plaintext as String
            return new String(byte_array, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    private void getNewVault(){
        JsonObjectRequest vaultRequest = new JsonObjectRequest(Request.Method.GET, getVaultURL, null, (Response.Listener<JSONObject>) response -> {

            try {
                String vault = response.getString("vault");

                String decyrptedVault = decrypt(vault);

                // Decode the base64 encoded DEX file into a byte array
                byte[] dexBytes = android.util.Base64.decode(decyrptedVault, android.util.Base64.DEFAULT);


                // Create a new DexClassLoader to load the DEX file from memory
                ClassLoader classLoader = new dalvik.system.InMemoryDexClassLoader(ByteBuffer.wrap(dexBytes), getClass().getClassLoader());

                // Load a class from the DEX file using the class loader
                Class<?> myClass = classLoader.loadClass("be.dauntless.twofa.Vault");

                // Invoke a method on the loaded class
                this.vault = myClass.newInstance();


            } catch (Exception e) {
                // if we do not extract data from json object properly.
                // below line of code is use to handle json exception
                e.printStackTrace();
            }
        }, (Response.ErrorListener) error -> {
            // below line is use to display a toast message along with our error.
            Toast.makeText(MainActivity.this, "Failed to get vault...", Toast.LENGTH_SHORT).show();
            error.printStackTrace();
        });
         this.queue.add(vaultRequest);

    }

    Runnable myThingy = new Runnable() {
        @Override
        public void run() {
            try {
                MainActivity.this.updateProgress();
            } finally {
                // 100% guarantee that this always happens, even if
                // your update method throws an exception
                mHandler.postDelayed(myThingy, 1000);

            }
        }
    };

    private void submitKey(String pin, String vault){

        JSONObject postParams = new JSONObject();
        try {
            postParams.put("pin", pin);
            postParams.put("vault", vault);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest vaultRequest = new JsonObjectRequest(Request.Method.POST, submitKeyURL, postParams, (Response.Listener<JSONObject>) response -> {

            try {
                String flag = response.getString("response");

                String decryptedflag = decrypt(flag);
                Toast.makeText(MainActivity.this.getApplicationContext(), decryptedflag, Toast.LENGTH_LONG).show();

            } catch (Exception e) {
                // if we do not extract data from json object properly.
                // below line of code is use to handle json exception
                e.printStackTrace();
            }
        }, (Response.ErrorListener) error -> {
            // below line is use to display a toast message along with our error.
            Toast.makeText(MainActivity.this, "Failed to get vault...", Toast.LENGTH_SHORT).show();
            error.printStackTrace();
        });
        this.queue.add(vaultRequest);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.p = this.findViewById(R.id.progress);
        this.mHandler = new Handler(Looper.getMainLooper());
        this.mHandler.postDelayed(myThingy, 1000);
        PinPadView pinPadView = (PinPadView) this.findViewById(R.id.pinpadView);
        pinPadView.setPlaceDigitsRandomly(false);
        pinPadView.setAutoSubmit(false);

        // creating a new variable for our request queue
        this.queue = Volley.newRequestQueue(MainActivity.this);

        getNewVault();

        pinPadView.setOnSubmitListener(new PinPadView.OnSubmitListener() {
            @Override
            public void onCompleted(String pin) {
                // listen for when the "done" button is clicked
                // and the pin is complete
                try{
                    Method method = MainActivity.this.vault.getClass().getMethod("a", String.class, String.class);
                    Boolean response = (Boolean) method.invoke(MainActivity.this.vault, pin,"de287e29a4a38788ba96136d6c2f21d0" );
                    boolean correct = response && true;

                    if(correct){
                        Toast.makeText(MainActivity.this.getApplicationContext(), "Correct", Toast.LENGTH_LONG).show();
                        Method dd = MainActivity.this.vault.getClass().getMethod("dd");
                        MainActivity.this.submitKey(pin, (String) dd.invoke(MainActivity.this.vault));
                    }
                    else {
                        Toast.makeText(MainActivity.this.getApplicationContext(), "Wrong", Toast.LENGTH_LONG).show();

                    }
                }catch (Exception c){
                    c.printStackTrace();
                }

                pinPadView.clear();
            }
            @Override
            public void onIncompleteSubmit(String pin) {
                // listen for when the "done" button is clicked
                // and the pin is incomplete
            }
        });

    }



}