Java.perform(function(){

    let MainActivity = Java.use("be.dauntless.twofa.MainActivity");
    MainActivity["decrypt"].implementation = function (str) {
        let result = this["decrypt"](str);
        console.log(`MainActivity.decrypt result=${result}`);
        return result;
    };
});