package be.dauntless.twofa;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import co.paystack.android.design.widget.PinPadView;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import dalvik.system.InMemoryDexClassLoader;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class MainActivity extends AppCompatActivity {
    private int c;
    private ClassLoader cl;
    private Handler mHandler;
    ProgressBar p;
    private RequestQueue queue;
    private Object vault;
    private int d = 30;
    private String getVaultURL = "http://99.81.5.42:9009/getvault";
    private String submitKeyURL = "http://99.81.5.42:9009/submitkey";
    Runnable myThingy = new Runnable() { // from class: be.dauntless.twofa.MainActivity.1
        @Override // java.lang.Runnable
        public void run() {
            try {
                MainActivity.this.updateProgress();
            } finally {
                MainActivity.this.mHandler.postDelayed(MainActivity.this.myThingy, 1000L);
            }
        }
    };

    /* JADX INFO: Access modifiers changed from: private */
    public void updateProgress() {
        int i = this.c + 1;
        this.c = i;
        int i2 = this.d;
        int i3 = i % i2;
        this.c = i3;
        this.p.setProgress((int) ((i3 / i2) * 100.0d));
        if (this.c == 0) {
            getNewVault();
        }
    }

    public static String decrypt(String str) {
        try {
            byte[] decode = Base64.getDecoder().decode(str);
            byte[] copyOfRange = Arrays.copyOfRange(decode, 0, 16);
            byte[] copyOfRange2 = Arrays.copyOfRange(decode, 16, decode.length);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(copyOfRange);
            SecretKeySpec secretKeySpec = new SecretKeySpec("ca1111c9f4a92797".getBytes("UTF-8"), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(2, secretKeySpec, ivParameterSpec);
            return new String(cipher.doFinal(copyOfRange2), StandardCharsets.UTF_8);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void getNewVault() {
        this.queue.add(new JsonObjectRequest(0, this.getVaultURL, null, new Response.Listener() { // from class: be.dauntless.twofa.MainActivity$$ExternalSyntheticLambda0
            @Override // com.android.volley.Response.Listener
            public final void onResponse(Object obj) {
                MainActivity.this.m30lambda$getNewVault$0$bedauntlesstwofaMainActivity((JSONObject) obj);
            }
        }, new Response.ErrorListener() { // from class: be.dauntless.twofa.MainActivity$$ExternalSyntheticLambda1
            @Override // com.android.volley.Response.ErrorListener
            public final void onErrorResponse(VolleyError volleyError) {
                MainActivity.this.m31lambda$getNewVault$1$bedauntlesstwofaMainActivity(volleyError);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$getNewVault$0$be-dauntless-twofa-MainActivity  reason: not valid java name */
    public /* synthetic */ void m30lambda$getNewVault$0$bedauntlesstwofaMainActivity(JSONObject jSONObject) {
        try {
            this.vault = new InMemoryDexClassLoader(ByteBuffer.wrap(android.util.Base64.decode(decrypt(jSONObject.getString("vault")), 0)), getClass().getClassLoader()).loadClass("be.dauntless.twofa.Vault").newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$getNewVault$1$be-dauntless-twofa-MainActivity  reason: not valid java name */
    public /* synthetic */ void m31lambda$getNewVault$1$bedauntlesstwofaMainActivity(VolleyError volleyError) {
        Toast.makeText(this, "Failed to get vault...", 0).show();
        volleyError.printStackTrace();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void submitKey(String str, String str2) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("pin", str);
            jSONObject.put("vault", str2);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        this.queue.add(new JsonObjectRequest(1, this.submitKeyURL, jSONObject, new Response.Listener() { // from class: be.dauntless.twofa.MainActivity$$ExternalSyntheticLambda2
            @Override // com.android.volley.Response.Listener
            public final void onResponse(Object obj) {
                MainActivity.this.m32lambda$submitKey$2$bedauntlesstwofaMainActivity((JSONObject) obj);
            }
        }, new Response.ErrorListener() { // from class: be.dauntless.twofa.MainActivity$$ExternalSyntheticLambda3
            @Override // com.android.volley.Response.ErrorListener
            public final void onErrorResponse(VolleyError volleyError) {
                MainActivity.this.m33lambda$submitKey$3$bedauntlesstwofaMainActivity(volleyError);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$submitKey$2$be-dauntless-twofa-MainActivity  reason: not valid java name */
    public /* synthetic */ void m32lambda$submitKey$2$bedauntlesstwofaMainActivity(JSONObject jSONObject) {
        try {
            Toast.makeText(getApplicationContext(), decrypt(jSONObject.getString("response")), 1).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$submitKey$3$be-dauntless-twofa-MainActivity  reason: not valid java name */
    public /* synthetic */ void m33lambda$submitKey$3$bedauntlesstwofaMainActivity(VolleyError volleyError) {
        Toast.makeText(this, "Failed to get vault...", 0).show();
        volleyError.printStackTrace();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.p = (ProgressBar) findViewById(R.id.progress);
        Handler handler = new Handler(Looper.getMainLooper());
        this.mHandler = handler;
        handler.postDelayed(this.myThingy, 1000L);
        final PinPadView pinPadView = (PinPadView) findViewById(R.id.pinpadView);
        pinPadView.setPlaceDigitsRandomly(false);
        pinPadView.setAutoSubmit(false);
        this.queue = Volley.newRequestQueue(this);
        getNewVault();
        pinPadView.setOnSubmitListener(new PinPadView.OnSubmitListener() { // from class: be.dauntless.twofa.MainActivity.2
            @Override // co.paystack.android.design.widget.PinPadView.OnSubmitListener
            public void onIncompleteSubmit(String str) {
            }

            @Override // co.paystack.android.design.widget.PinPadView.OnSubmitListener
            public void onCompleted(String str) {
                try {
                    if (((Boolean) MainActivity.this.vault.getClass().getMethod("a", String.class, String.class).invoke(MainActivity.this.vault, str, "de287e29a4a38788ba96136d6c2f21d0")).booleanValue()) {
                        Toast.makeText(MainActivity.this.getApplicationContext(), "Correct", 1).show();
                        Method method = MainActivity.this.vault.getClass().getMethod("dd", new Class[0]);
                        MainActivity mainActivity = MainActivity.this;
                        mainActivity.submitKey(str, (String) method.invoke(mainActivity.vault, new Object[0]));
                    } else {
                        Toast.makeText(MainActivity.this.getApplicationContext(), "Wrong", 1).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                pinPadView.clear();
            }
        });
    }
}