#!/bin/sh

# preparing network
echo --- PREPARING NETWORK ---
iptables -F
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT
iptables -A INPUT -i eth1 -s 192.168.0.0/16 -p TCP --dport quote -j ACCEPT
iptables -A INPUT -i eth1 -s 192.168.0.0/16 -p TCP --dport www -j ACCEPT
if $DEBUG; then iptables -A INPUT -i eth1 -s 192.168.0.0/16 -p icmp -j ACCEPT; fi
ip addr flush dev eth1
ip addr add $IP_NC dev eth1
if $DEBUG; then ip addr; fi

# preparing config files
echo --- PREPARING FILES ---
printf "Nice job breaking it, hero.\n$FLAG" > /gladoslan/flag.txt
soffice --writer --convert-to pdf /gladoslan/flag.txt --outdir /gladoslan
qpdf --encrypt $USER_KEY $OWNER_KEY 128 --use-aes=y -- /gladoslan/flag.pdf /gladoslan/encflag.pdf
convert-6 -size 500x50 xc:white -font '/usr/share/fonts/misc/ter-x12n.pcf.gz' -gravity center -pointsize 12 -fill black -annotate 0 "$USER_KEY" -trim -border 1 /gladoslan/www/key.png #TXT2PNG
ENCODED_FLAG=$(cat /gladoslan/encflag.pdf | xxd -p | tr -d \\n)
rm /gladoslan/flag.txt
rm /gladoslan/flag.pdf
rm /gladoslan/encflag.pdf
mkdir -p /run/nginx/
touch /run/nginx/nginx.pid
cp /gladoslan/gladoslanwww.conf /etc/nginx/http.d/
rm /etc/nginx/http.d/default.conf
chmod 755 /gladoslan/www

# starting web server
echo --- STARTING WEB SERVER ---
#nginx -g 'daemon off;'
nginx

# starting netcat server
echo --- STARTING NETCAT SERVER ---
ncat -v -4lk 17 --send-only -c "echo Well you found me. Congratulations. Was it worth it? Because despite your violent behaviour, the only thing you have managed to break so far, is my heart. && echo $ENCODED_FLAG"
