sudo docker system prune

CMD="sudo docker ps -a -q"
sudo docker stop $(eval $CMD)
sudo docker rm $(eval $CMD)

CMD="sudo docker images -q"
sudo docker rmi $(eval $CMD)
