#!/bin/sh

# preparing network
echo --- PREPARING NETWORK ---
iptables -F
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT
iptables -A INPUT -i eth1 -p UDP --sport bootpc --dport bootps -j ACCEPT
if $DEBUG; then iptables -A INPUT -i eth1 -s 10.0.0.0/8 -p icmp -j ACCEPT; fi
ip addr flush dev eth1
ip addr add $IP_DHCP dev eth1
if $DEBUG; then ip addr; fi

# preparing config files
echo --- PREPARING FILES ---
convert-6 -size 500x50 xc:white -font '/usr/share/fonts/misc/ter-x12n.pcf.gz' -gravity center -pointsize 12 -fill black -annotate 0 "$FLAG2" -trim -border 1 /gladoslan/flag.png #TXT2PNG
ENCODED_FLAG=$(base64 /gladoslan/flag.png | tr -d \\n) #BASE64
rm /gladoslan/flag.png
sed -i "s/{{IP_DNS}}/$(echo $IP_DNS | cut -d'/' -f 1)/g" /gladoslan/dhcpd.conf
sed -i "s/{{FLAG1}}/$FLAG1/g" /gladoslan/dhcpd.conf
sed -i "s#{{FLAG2}}#$ENCODED_FLAG#g" /gladoslan/dhcpd.conf
cp /gladoslan/dhcpd.conf /etc/dhcp/
touch /var/lib/dhcp/dhcpd.leases

# starting dhcp server
echo --- STARTING DHCP SERVER ---
dhcpd -4 -f
