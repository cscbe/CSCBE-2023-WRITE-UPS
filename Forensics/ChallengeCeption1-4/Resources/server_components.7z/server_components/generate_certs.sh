
#---------------------------------#
# Generate OpenVPN pre-shared key #
#---------------------------------#

# Install requirements
sudo apt install -y openvpn

# Clean environment
rm *.crt *.key *.srl *.csr -f

### Create pre-shared key between server & client to reduce DDoS attacks
touch tls-auth.key
chmod 600 tls-auth.key
sudo openvpn --genkey secret tls-auth.key



#----------------------------------#
# Elliptic Curve (EC) Cryptography #
#----------------------------------#


### Find safe curves: http://safecurves.cr.yp.to/
### Check which curves are supported by browser: https://www.ssllabs.com/ssltest/viewMyClient.html
#openssl ecparam -list_curves	#list curves supported by OpenSSL

CERT_ROOT_NAME='gladoslan_root'
CERT_CONF="./certs.conf"
### Generate 1 year valid root EC certificate
touch $CERT_ROOT_NAME.key
chmod 600 $CERT_ROOT_NAME.key
openssl ecparam -genkey -out $CERT_ROOT_NAME.key -name 'secp521r1'
openssl req -new -x509 -key $CERT_ROOT_NAME.key -out $CERT_ROOT_NAME.crt -config $CERT_CONF -days 365 -sha512 -extensions 'root' -subj '/C=BE/O=CyberSecurityChallenge/CN=GLaDOS.lan Root'

### Generate 6 months valid server EC certificate
CERT_NAME='gladoslan_ovpn_server'
touch $CERT_NAME.key
chmod 600 $CERT_NAME.key
openssl ecparam -genkey -out $CERT_NAME.key -name 'secp521r1'
openssl req -new -key $CERT_NAME.key -out $CERT_NAME.csr -config $CERT_CONF -subj '/C=BE/O=CyberSecurityChallenge/CN=GLaDOS.lan OVPN Server'
openssl x509 -req -CA $CERT_ROOT_NAME.crt -CAkey $CERT_ROOT_NAME.key -CAcreateserial -extfile $CERT_CONF -sha512 -days 182 -extensions 'server' -in $CERT_NAME.csr -out $CERT_NAME.crt
rm $CERT_NAME.csr

### Generate 10 years valid client EC certificate
CERT_NAME='gladoslan_ovpn_client'
touch $CERT_NAME.key
chmod 600 $CERT_NAME.key
openssl ecparam -genkey -out $CERT_NAME.key -name 'secp521r1'
openssl req -new -key $CERT_NAME.key -out $CERT_NAME.csr -config $CERT_CONF -subj '/C=BE/O=CyberSecurityChallenge/CN=GLaDOS.lan OVPN Client'
openssl x509 -req -CA $CERT_ROOT_NAME.crt -CAkey $CERT_ROOT_NAME.key -CAcreateserial -extfile $CERT_CONF -sha512 -days 182 -extensions 'client' -in $CERT_NAME.csr -out $CERT_NAME.crt
rm $CERT_NAME.csr

### Check certificate details
openssl x509 -noout -text -in $CERT_NAME.crt

# Cleanup
rm -f *.srl *root.key
