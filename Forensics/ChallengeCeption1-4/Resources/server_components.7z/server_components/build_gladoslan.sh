sudo apt install -y docker-compose
sudo docker-compose down
sudo docker-compose rm --stop --force
sudo docker-compose up --build
exit
