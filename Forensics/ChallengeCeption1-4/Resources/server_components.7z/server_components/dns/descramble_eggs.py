import sys

def descramble_eggs(text):
    decoded=''
    for x in range(len(text)):
        decoded += text[x] + text[::-1][x]
    return decoded[:int(len(decoded)/2)]

def main(argv):
    tmp=argv[0]
    for x in range(int(argv[1])):
        tmp = descramble_eggs(tmp)
    print(tmp)

if __name__ == "__main__":
   main(sys.argv[1:])
