import sys

def scramble_eggs(text):
    encoded1=''
    encoded2=''
    for x in range(len(text)):
        if x%2: encoded2 += text[x]
        else: encoded1 += text[x]
    return encoded1 + encoded2[::-1]

def main(argv):
    tmp=argv[0]
    for x in range(int(argv[1])):
        tmp = scramble_eggs(tmp)
    print(tmp)

if __name__ == "__main__":
   main(sys.argv[1:])
