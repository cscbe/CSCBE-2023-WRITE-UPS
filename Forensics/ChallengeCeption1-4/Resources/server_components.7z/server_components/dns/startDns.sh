#!/bin/sh

# preparing network
echo --- PREPARING NETWORK ---
iptables -F
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT
iptables -A INPUT -i eth1 -s 192.168.0.0/16 -p UDP --dport domain -j ACCEPT
iptables -A INPUT -i eth1 -s 192.168.0.0/16 -p TCP --dport domain -j ACCEPT
if $DEBUG; then iptables -A INPUT -i eth1 -s 192.168.0.0/16 -p icmp -j ACCEPT; fi
ip addr flush dev eth1
ip addr add $IP_DNS dev eth1
if $DEBUG; then ip addr; fi

# preparing config files
echo --- PREPARING FILES ---
ENCODED_FLAG=$(python3 /gladoslan/scramble_eggs.py "$FLAG" $SCRAMBLE_X_TIMES)
sed -i "s/{{FLAG}}/$ENCODED_FLAG/g" /gladoslan/gladoslan.conf
sed -i "s/{{IP_DNS}}/$(echo $IP_DNS | cut -d'/' -f 1)/g" /gladoslan/gladoslan.conf
sed -i "s/{{IP_CROWNJEWELS}}/$(echo $IP_CROWNJEWELS | cut -d'/' -f 1)/g" /gladoslan/gladoslan.conf
sed -i "s/{{XTIMES}}/$(echo $SCRAMBLE_X_TIMES)/g" /gladoslan/gladoslan.conf
cp /gladoslan/named.conf /etc/bind/
cp /gladoslan/gladoslan.conf /etc/bind/
rndc-confgen -a -A hmac-sha512 -b 512
chmod 404 /etc/bind/rndc.key

# starting dns server
echo --- STARTING DNS SERVER ---
named -4 -g -c /etc/bind/named.conf
