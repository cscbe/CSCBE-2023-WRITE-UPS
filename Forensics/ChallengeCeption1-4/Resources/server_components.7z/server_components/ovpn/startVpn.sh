#!/bin/sh

# prepare network
echo --- PREPARING NETWORK ---
iptables -F
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT
iptables -A INPUT -i eth0 -p UDP --dport openvpn -j ACCEPT
iptables -A FORWARD -i br0 -j ACCEPT
#cp /usr/etc/ethertypes /etc/
ebtables -F
ebtables -P INPUT DROP
ebtables -P FORWARD DROP
ebtables -P OUTPUT DROP
ebtables -A FORWARD -p IPv4 -j ACCEPT
ebtables -A FORWARD -p ARP -j ACCEPT
# create tap interface
openvpn --mktun --dev tap0
# create bridge
ip addr flush dev eth1
ip addr flush dev tap0
brctl addbr br0
brctl stp br0 off
brctl addif br0 tap0 eth1
ip link set tap0 up
ip link set br0 up
if $DEBUG; then ip addr; fi

# prepare files
echo --- PREPARING FILES ---
chmod 400 /gladoslan/keys/*
IP_OVPN=$(ip addr show eth0 | grep -Po 'inet \K[\d.]+')
sed -i "s/{{IP_OVPN}}/$IP_OVPN/g" /gladoslan/ovpn_server.conf

# start OpenVPN
echo --- STARTING OPENVPN SERVER ---
openvpn /gladoslan/ovpn_server.conf
